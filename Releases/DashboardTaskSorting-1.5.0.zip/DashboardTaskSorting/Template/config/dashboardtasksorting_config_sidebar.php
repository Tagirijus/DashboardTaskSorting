<li <?= $this->app->checkMenuSelection('DashboardTaskSortingController', 'show') ?>>
    <a href="/dashboardtasksorting/config"><?= t('DashboardTaskSorting configuration') ?></a>
</li>
