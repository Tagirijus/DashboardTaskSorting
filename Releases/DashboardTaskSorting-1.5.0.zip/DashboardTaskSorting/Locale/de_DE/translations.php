<?php

return array(
    'DashboardTaskSorting configuration' => 'DashboardTaskSorting Einstellungen',
    'Group columns' => 'Gruppiere Spalten',
    'Enter column names comma seperated, which should be grouped together.' => 'Gib Komma getrennt die Spaltennamen ein, die gruppiert werden sollen.',
    'Group' => 'Gruppe',
    'Group captions' => 'Gruppen-Bezeichnung',
    'The captions / titles for the group-columns on the dashboard.' => 'Die Bezeichnungen für die Spalten-Gruppen auf dem Dashboard.',
    'caption' => 'Bezeichnung'
);
